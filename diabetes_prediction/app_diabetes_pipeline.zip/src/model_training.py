""" model_training.py """

from mls_lib.model_training import SVMTrainer, TrainTestSplitter
from mls_lib.orchestration import Stage

def create_model_training():
    mt =  Stage('Model Training')

    split_train_test = TrainTestSplitter(
        train_percentage = 0
    )
    mt.add_task(
        split_train_test,
        features = (mt, 'features'),
        truth = (mt, 'truth')
    )
    
    svm_train = SVMTrainer(
        kernel = 'poly'
    )
    mt.add_task(
        svm_train,
        features = (split_train_test, 'features_train'),
        truth = (split_train_test, 'truth_train')
    )
    
    mt.add_output('diabetes_model', (svm_train, 'model'))
    mt.add_output('features_test', (split_train_test, 'features_test'))
    mt.add_output('truth_test', (split_train_test, 'truth_test'))
    
    return mt

