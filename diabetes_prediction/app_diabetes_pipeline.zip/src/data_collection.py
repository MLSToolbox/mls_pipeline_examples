""" data_collection.py """

from mls_lib.data_collection import CSVLoader
from mls_lib.orchestration import Stage

def create_data_collection():
    dc =  Stage('Data Collection')

    # Gets the data to train
    csvloader = CSVLoader(
        path = 'diabetes_dataset.csv',
        separator = ','
    )
    dc.add_task(
        csvloader
    )
    
    dc.add_output('diabetes_data', (csvloader, 'out'))
    
    return dc

