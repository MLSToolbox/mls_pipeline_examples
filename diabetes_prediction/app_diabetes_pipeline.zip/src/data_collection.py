""" data_collection.py """

from mls_lib.data_collection import CSVLoader
from mls_lib.orchestration import Stage, ParamLoader

def create_data_collection():
    dc =  Stage('Data Collection')

    csvloader = CSVLoader(
        path =  ParamLoader.load('data_collection.dataset_path')
    )
    dc.add_task(
        csvloader
    )
    
    dc.add_output('diabetes_data', (csvloader, 'out'))
    
    return dc

