""" feature_engineering.py """

from mls_lib.feature_engineering import ColumnDrop, ColumnSelect
from mls_lib.orchestration import ParamLoader, Stage
from mls_lib.feature_engineering.scaler_training import StandardScalerTrainer

def create_feature_engineering():
    fe =  Stage('Feature Engineering')

    select_columns = ColumnSelect(
        columns =  ParamLoader.load('feature_engineering.truth_column')
    )
    fe.add_task(
        select_columns,
        origin_table = (fe, 'data')
    )
    
    standard_scaler_train = StandardScalerTrainer(
        columns =  ParamLoader.load('feature_engineering.truth_column')
    )
    fe.add_task(
        standard_scaler_train,
        data = (select_columns, 'resulting_table')
    )
    
    drop_columns = ColumnDrop(
        columns =  ParamLoader.load('feature_engineering.truth_column')
    )
    fe.add_task(
        drop_columns,
        origin_table = (fe, 'data')
    )
    
    standard_scaler_train_2 = StandardScalerTrainer(
        columns = [
            'S1',
            'S2',
            'S3',
            'S4'
        ]
    )
    fe.add_task(
        standard_scaler_train_2,
        data = (drop_columns, 'resulting_table')
    )
    
    fe.add_output('features', (standard_scaler_train_2, 'out'))
    fe.add_output('truth', (standard_scaler_train, 'out'))
    
    return fe

