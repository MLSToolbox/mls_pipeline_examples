import warnings
warnings.filterwarnings('ignore')

from mls_lib.orchestration import Pipeline
from data_collection import create_data_collection
from feature_engineering import create_feature_engineering
from model_train import create_model_train
from model_evaluation import create_model_evaluation

def main():
    root = Pipeline()
    data_collection = create_data_collection()
    root.add_stage(data_collection, 
    )

    feature_engineering = create_feature_engineering()
    root.add_stage(feature_engineering, 
        data = (data_collection, 'diabetes_data'),
    )

    model_train = create_model_train()
    root.add_stage(model_train, 
        features = (feature_engineering, 'features'),
        truth = (feature_engineering, 'truth'),
    )

    model_evaluation = create_model_evaluation()
    root.add_stage(model_evaluation, 
        features = (model_train, 'features test'),
        model = (model_train, 'diabetes_model'),
        truth = (model_train, 'truth test'),
    )

    root.execute()

if __name__ == '__main__':
    main()