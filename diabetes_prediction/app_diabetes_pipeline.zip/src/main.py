from mls_lib.orchestration import Pipeline
from data_collection import create_data_collection
from feature_engineering import create_feature_engineering
from model_training import create_model_training
from model_evaluation import create_model_evaluation

def main():
    root = Pipeline()
    data_collection = create_data_collection()
    root.add_stage(data_collection, 
    )

    feature_engineering = create_feature_engineering()
    root.add_stage(feature_engineering, 
        data = (data_collection, 'diabetes_data'),
    )

    model_training = create_model_training()
    root.add_stage(model_training, 
        features = (feature_engineering, 'features'),
        truth = (feature_engineering, 'truth'),
    )

    model_evaluation = create_model_evaluation()
    root.add_stage(model_evaluation, 
        features = (model_training, 'features_test'),
        truth = (model_training, 'truth_test'),
        model = (model_training, 'diabetes_model'),
    )

    root.execute()

if __name__ == '__main__':
    main()