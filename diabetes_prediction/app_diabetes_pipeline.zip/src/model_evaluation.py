""" model_evaluation.py """

from mls_lib.model_evaluation import EvaluateAccuracy
from mls_lib.orchestration import Stage

def create_model_evaluation():
    me =  Stage('Model evaluation')

    evaluate_accuracy = EvaluateAccuracy()
    me.add_task(
        evaluate_accuracy,
        model = (me, 'model'),
        features = (me, 'features'),
        truth = (me, 'truth')
    )
    
    
    return me

