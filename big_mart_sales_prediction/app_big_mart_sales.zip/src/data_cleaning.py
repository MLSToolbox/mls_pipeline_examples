""" data_cleaning.py """

from mls_lib.data_cleaning import ReplaceNullMode, ReplaceNullAverage
from mls_lib.orchestration import Stage

def create_data_cleaning():
    dc =  Stage('Data Cleaning')

    # Item weight
    replace_nulls_average = ReplaceNullAverage(
        column = 'Item_Weight'
    )
    dc.add_task(
        replace_nulls_average,
        data_in = (dc, 'raw_data')
    )
    
    # Outlet Size
    replace_nulls_mode = ReplaceNullMode(
        column = 'Outlet_Size'
    )
    dc.add_task(
        replace_nulls_mode,
        data_in = (replace_nulls_average, 'out')
    )
    
    dc.add_output('clean_data', (replace_nulls_mode, 'out'))
    
    return dc

