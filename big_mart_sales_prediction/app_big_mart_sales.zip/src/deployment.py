""" deployment.py """

from mls_lib.deployment import ToCSV, ModelPredict
from mls_lib.orchestration import Stage

def create_deployment():
    d =  Stage('Deployment')

    model_predict = ModelPredict()
    d.add_task(
        model_predict,
        model = (d, 'model'),
        features = (d, 'features')
    )
    
    to_csv = ToCSV(
        path = './data/out.csv'
    )
    d.add_task(
        to_csv,
        dataframe = (model_predict, 'prediction')
    )
    
    
    return d

