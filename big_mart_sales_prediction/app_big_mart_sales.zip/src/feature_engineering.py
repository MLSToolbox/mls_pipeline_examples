""" feature_engineering.py """

from mls_lib.feature_engineering.scaler_training import StandardScalerTrainer, MinMaxScalerTrainer
from mls_lib.feature_engineering import SplitDataframe, PrefixTransform, DuplicateColumn, ColumnDrop
from mls_lib.data_cleaning import ReplaceValue
from mls_lib.feature_engineering.encoder_training import OneHotEncoderTrainer
from mls_lib.orchestration import Stage

def create_feature_engineering():
    fe =  Stage('Feature Engineering')

    split_dataframe = SplitDataframe(
        columns = [
            'Item_Outlet_Sales'
        ]
    )
    fe.add_task(
        split_dataframe,
        table = (fe, 'data')
    )
    
    standard_scaler_train = StandardScalerTrainer(
        columns = [
            'Item_Visibility'
        ]
    )
    fe.add_task(
        standard_scaler_train,
        data = (split_dataframe, 'unselected_table')
    )
    
    # New Item Type
    duplicate_column = DuplicateColumn(
        original_column_name = 'Item_Identifier',
        new_column_name = 'Item_Type_Combined'
    )
    fe.add_task(
        duplicate_column,
        old_table = (standard_scaler_train, 'out')
    )
    
    prefix_transform = PrefixTransform(
        columns = [
            'Item_Type_Combined'
        ],
        prefix_length = 2
    )
    fe.add_task(
        prefix_transform,
        old_table = (duplicate_column, 'new_table')
    )
    
    replace_value = ReplaceValue(
        column = 'Item_Type_Combined',
        value_map = {
            'FD': 'Food',
            'NC': 'Non-Consumable',
            'DR': 'Drinks'
        }
    )
    fe.add_task(
        replace_value,
        data_in = (prefix_transform, 'new_table')
    )
    
    # Outlet Age
    minmax_scaler_train = MinMaxScalerTrainer(
        columns = [
            'Outlet_Establishment_Year'
        ]
    )
    fe.add_task(
        minmax_scaler_train,
        data = (replace_value, 'out')
    )
    
    replace_value_2 = ReplaceValue(
        column = 'Item_Fat_Content',
        value_map = {
            'LF': 'Low Fat',
            'reg': 'Regular',
            'low fat': 'Low Fat'
        }
    )
    fe.add_task(
        replace_value_2,
        data_in = (minmax_scaler_train, 'out')
    )
    
    # encode all categorical
    ohcencoder_train = OneHotEncoderTrainer(
        columns = [
            'Item_Fat_Content',
            'Outlet_Location_Type',
            'Outlet_Size',
            'Outlet_Type',
            'Item_Type_Combined',
            'Outlet_Identifier',
            'Item_Type'
        ]
    )
    fe.add_task(
        ohcencoder_train,
        data = (replace_value_2, 'out')
    )
    
    drop_columns = ColumnDrop(
        columns = [
            'Item_Identifier'
        ]
    )
    fe.add_task(
        drop_columns,
        origin_table = (ohcencoder_train, 'out')
    )
    
    fe.add_output('features', (drop_columns, 'resulting_table'))
    fe.add_output('truth', (split_dataframe, 'selected_table'))
    fe.add_output('item_v_scaler', (standard_scaler_train, 'scaler'))
    fe.add_output('outlet_y_scaler', (minmax_scaler_train, 'scaler'))
    fe.add_output('categorical_encoder', (ohcencoder_train, 'encoder'))
    
    return fe

