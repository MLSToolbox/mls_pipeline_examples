""" model_train.py """

from mls_lib.model_training import RandomForestRegressorTrainer, TrainTestSplitter
from mls_lib.orchestration import Stage, ParamLoader

def create_model_train():
    mt =  Stage('Model Train')

    split_train_test = TrainTestSplitter(
        train_percentage =  ParamLoader.load('model_train.train_percentage')
    )
    mt.add_task(
        split_train_test,
        features = (mt, 'features'),
        truth = (mt, 'truth')
    )
    
    random_forest_regressor_train = RandomForestRegressorTrainer(
        n_estimators =  ParamLoader.load('model_train.n_estimators'),
        max_depth = 7,
        min_samples_leaf =  ParamLoader.load('model_train.min_samples_leaf')
    )
    mt.add_task(
        random_forest_regressor_train,
        features = (split_train_test, 'features_train'),
        truth = (split_train_test, 'truth_train')
    )
    
    mt.add_output('model', (random_forest_regressor_train, 'model'))
    mt.add_output('features_test', (split_train_test, 'features_test'))
    mt.add_output('truth_test', (split_train_test, 'truth_test'))
    
    return mt

