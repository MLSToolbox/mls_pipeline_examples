""" reuse_f_engineering.py """

from mls_lib.feature_engineering import ReuseScaler, PrefixTransform, DuplicateColumn, ColumnDrop, ReuseEncoder
from mls_lib.data_cleaning import ReplaceValue
from mls_lib.orchestration import Stage

def create_reuse_f_engineering():
    rfe =  Stage('Reuse F Engineering')

    reuse_scaler = ReuseScaler()
    rfe.add_task(
        reuse_scaler,
        data = (rfe, 'data'),
        scaler = (rfe, 'iv_sc')
    )
    
    # New Item Type
    duplicate_column = DuplicateColumn(
        original_column_name = 'Item_Identifier',
        new_column_name = 'Item_Type_Combined'
    )
    rfe.add_task(
        duplicate_column,
        old_table = (reuse_scaler, 'out')
    )
    
    prefix_transform = PrefixTransform(
        columns = [
            'Item_Type_Combined'
        ],
        prefix_length = 2
    )
    rfe.add_task(
        prefix_transform,
        old_table = (duplicate_column, 'new_table')
    )
    
    replace_value = ReplaceValue(
        column = 'Item_Type_Combined',
        value_map = {
            'FD': 'Food',
            'NC': 'Non-Consumable',
            'DR': 'Drinks'
        }
    )
    rfe.add_task(
        replace_value,
        data_in = (prefix_transform, 'new_table')
    )
    
    reuse_scaler_2 = ReuseScaler()
    rfe.add_task(
        reuse_scaler_2,
        data = (replace_value, 'out'),
        scaler = (rfe, 'oy_sc')
    )
    
    replace_value_2 = ReplaceValue(
        column = 'Item_Fat_Content',
        value_map = {
            'LF': 'Low Fat',
            'reg': 'Regular',
            'low fat': 'Low Fat'
        }
    )
    rfe.add_task(
        replace_value_2,
        data_in = (reuse_scaler_2, 'out')
    )
    
    reuse_encoder = ReuseEncoder()
    rfe.add_task(
        reuse_encoder,
        encoder = (rfe, 'c_enc'),
        data = (replace_value_2, 'out')
    )
    
    drop_columns = ColumnDrop(
        columns = [
            'Item_Identifier'
        ]
    )
    rfe.add_task(
        drop_columns,
        origin_table = (reuse_encoder, 'out')
    )
    
    rfe.add_output('features', (drop_columns, 'resulting_table'))
    
    return rfe

