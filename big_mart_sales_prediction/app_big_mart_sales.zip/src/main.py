from mls_lib.orchestration import Pipeline
from data_collection import create_data_collection
from data_cleaning import create_data_cleaning
from feature_engineering import create_feature_engineering
from reuse_f_engineering import create_reuse_f_engineering
from model_train import create_model_train
from model_evaluation import create_model_evaluation
from deployment import create_deployment

def main():
    root = Pipeline()
    data_collection = create_data_collection()
    root.add_stage(data_collection, 
    )

    data_cleaning = create_data_cleaning()
    root.add_stage(data_cleaning, 
        raw_data = (data_collection, 'train'),
    )

    feature_engineering = create_feature_engineering()
    root.add_stage(feature_engineering, 
        data = (data_cleaning, 'clean_data'),
    )

    data_cleaning_2 = create_data_cleaning()
    root.add_stage(data_cleaning_2, 
        raw_data = (data_collection, 'valid'),
    )

    reuse_f_engineering = create_reuse_f_engineering()
    root.add_stage(reuse_f_engineering, 
        data = (data_cleaning_2, 'clean_data'),
        iv_sc = (feature_engineering, 'item_v_scaler'),
        oy_sc = (feature_engineering, 'outlet_y_scaler'),
        c_enc = (feature_engineering, 'categorical_encoder'),
    )

    model_train = create_model_train()
    root.add_stage(model_train, 
        features = (feature_engineering, 'features'),
        truth = (feature_engineering, 'truth'),
    )

    model_evaluation = create_model_evaluation()
    root.add_stage(model_evaluation, 
        model = (model_train, 'model'),
        features = (model_train, 'features_test'),
        truth = (model_train, 'truth_test'),
    )

    deployment = create_deployment()
    root.add_stage(deployment, 
        model = (model_train, 'model'),
        features = (reuse_f_engineering, 'features'),
    )

    root.execute()

if __name__ == '__main__':
    main()