""" data_collection.py """

from mls_lib.data_collection import CSVLoader
from mls_lib.orchestration import Stage

def create_data_collection():
    dc =  Stage('Data Collection')

    # Loads train data
    csvloader = CSVLoader(
        path = './data/train.csv'
    )
    dc.add_task(
        csvloader
    )
    
    # Loads test data
    csvloader_2 = CSVLoader(
        path = './data/test.csv'
    )
    dc.add_task(
        csvloader_2
    )
    
    dc.add_output('train', (csvloader, 'out'))
    dc.add_output('valid', (csvloader_2, 'out'))
    
    return dc

