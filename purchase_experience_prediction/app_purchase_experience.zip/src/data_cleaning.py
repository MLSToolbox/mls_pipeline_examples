""" data_cleaning.py """

from mls_lib.data_cleaning import ReplaceNullMedian, ReplaceNullText
from mls_lib.orchestration import Stage

def create_data_cleaning():
    dc =  Stage('Data Cleaning')

    # product_weight_g
    replace_nulls_median = ReplaceNullMedian(
        column = 'product_weight_g'
    )
    dc.add_task(
        replace_nulls_median,
        data_in = (dc, 'purchase_data')
    )
    
    # product_length_cm
    replace_nulls_median_2 = ReplaceNullMedian(
        column = 'product_length_cm'
    )
    dc.add_task(
        replace_nulls_median_2,
        data_in = (replace_nulls_median, 'out')
    )
    
    # product_height_cm
    replace_nulls_median_3 = ReplaceNullMedian(
        column = 'product_height_cm'
    )
    dc.add_task(
        replace_nulls_median_3,
        data_in = (replace_nulls_median_2, 'out')
    )
    
    # product_width_cm
    replace_nulls_median_4 = ReplaceNullMedian(
        column = 'product_width_cm'
    )
    dc.add_task(
        replace_nulls_median_4,
        data_in = (replace_nulls_median_3, 'out')
    )
    
    # review_comment_message
    replace_nulls_text = ReplaceNullText(
        new_value = 'No review',
        column = 'review_comment_message'
    )
    dc.add_task(
        replace_nulls_text,
        data_in = (replace_nulls_median_4, 'out')
    )
    
    dc.add_output('clean_data', (replace_nulls_text, 'out'))
    
    return dc

