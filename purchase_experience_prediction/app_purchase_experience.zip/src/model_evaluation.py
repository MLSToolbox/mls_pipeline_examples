""" model_evaluation.py """

from mls_lib.model_evaluation import EvaluateAccuracy, EvaluateMSE, EvaluateR2
from mls_lib.orchestration import Stage

def create_model_evaluation():
    me =  Stage('Model evaluation')

    evaluate_r2 = EvaluateR2()
    me.add_task(
        evaluate_r2,
        model = (me, 'model'),
        features = (me, 'features'),
        truth = (me, 'truth')
    )
    
    evaluate_accuracy = EvaluateAccuracy()
    me.add_task(
        evaluate_accuracy,
        model = (me, 'model'),
        features = (me, 'features'),
        truth = (me, 'truth')
    )
    
    evaluate_mse = EvaluateMSE()
    me.add_task(
        evaluate_mse,
        truth = (me, 'truth'),
        features = (me, 'features'),
        model = (me, 'model')
    )
    
    
    return me

