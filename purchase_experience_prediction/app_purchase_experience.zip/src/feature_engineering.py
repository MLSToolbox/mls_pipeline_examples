""" feature_engineering.py """

from mls_lib.feature_engineering import ColumnDrop, ColumnSelect
from mls_lib.orchestration import Stage

def create_feature_engineering():
    fe =  Stage('Feature Engineering')

    drop_columns = ColumnDrop(
        columns = [
            'order_approved_at',
            'order_delivered_carrier_date',
            'order_delivered_customer_date',
            'order_estimated_delivery_date',
            'order_purchase_timestamp',
            'customer_zip_code_prefix',
            'order_item_id'
        ]
    )
    fe.add_task(
        drop_columns,
        origin_table = (fe, 'data')
    )
    
    select_columns = ColumnSelect(
        columns = [
            'review_score'
        ]
    )
    fe.add_task(
        select_columns,
        origin_table = (drop_columns, 'resulting_table')
    )
    
    drop_columns_2 = ColumnDrop(
        columns = [
            'review_score'
        ]
    )
    fe.add_task(
        drop_columns_2,
        origin_table = (drop_columns, 'resulting_table')
    )
    
    fe.add_output('features', (drop_columns_2, 'resulting_table'))
    fe.add_output('truth', (select_columns, 'resulting_table'))
    
    return fe

