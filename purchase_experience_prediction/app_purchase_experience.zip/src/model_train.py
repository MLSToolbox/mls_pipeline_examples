""" model_train.py """

from mls_lib.model_training import LinearRegressorTrainer, TrainTestSplitter
from mls_lib.orchestration import Stage

def create_model_train():
    mt =  Stage('Model Train')

    split_train_test = TrainTestSplitter(
        train_percentage = 0.8
    )
    mt.add_task(
        split_train_test,
        features = (mt, 'features'),
        truth = (mt, 'truth')
    )
    
    linear_regressor_train = LinearRegressorTrainer()
    mt.add_task(
        linear_regressor_train,
        features = (split_train_test, 'features_train'),
        truth = (split_train_test, 'truth_train')
    )
    
    mt.add_output('trained_model', (linear_regressor_train, 'model'))
    mt.add_output('features test', (split_train_test, 'features_test'))
    mt.add_output('truth test', (split_train_test, 'truth_test'))
    
    return mt

