""" model_evaluation.py """

from mls_lib.deployment import ModelPredict, ToCSV
from mls_lib.feature_engineering import Map
from mls_lib.orchestration import ParamLoader, Stage
from mls_lib.model_evaluation import EvaluateClassificationReport, EvaluateConfusionMatrix

def create_model_evaluation():
    me =  Stage('Model evaluation')

    confusion_matrix = EvaluateConfusionMatrix()
    me.add_task(
        confusion_matrix,
        model = (me, 'model'),
        features = (me, 'features_test'),
        truth = (me, 'truth_test')
    )
    
    classification_report = EvaluateClassificationReport()
    me.add_task(
        classification_report,
        model = (me, 'model'),
        features = (me, 'features_test'),
        truth = (me, 'truth_test')
    )
    
    model_predict = ModelPredict()
    me.add_task(
        model_predict,
        model = (me, 'model'),
        features = (me, 'features_test')
    )
    
    map = Map(
        target_col = 'labels',
        index_col = 'label_names'
    )
    me.add_task(
        map,
        index = (me, 'labels'),
        origin_table = (model_predict, 'prediction')
    )
    
    to_csv = ToCSV(
        path =  ParamLoader.load('model_evaluation.output_path')
    )
    me.add_task(
        to_csv,
        dataframe = (map, 'resulting_table')
    )
    
    
    return me

