""" model_evaluation.py """

from mls_lib.deployment import ModelPredict, ToCSV
from mls_lib.feature_engineering import Map
from mls_lib.orchestration import ParamLoader, Stage

def create_model_evaluation():
    me =  Stage('Model evaluation')

    model_predict = ModelPredict()
    me.add_task(
        model_predict,
        model = (me, 'model'),
        features = (me, 'features_test')
    )
    
    map = Map(
        target_col = 'labels',
        index_col = 'label_names'
    )
    me.add_task(
        map,
        index = (me, 'labels'),
        origin_table = (model_predict, 'prediction')
    )
    
    to_csv = ToCSV(
        path =  ParamLoader.load('model_evaluation.output_path')
    )
    me.add_task(
        to_csv,
        dataframe = (map, 'resulting_table')
    )
    
    
    return me

