""" feature_engineering.py """

from mls_lib.feature_engineering import BasicOperator, ColumnSelect, GenerateSubset
from mls_lib.orchestration import Stage

def create_feature_engineering():
    fe =  Stage('Feature Engineering')

    # Subset for fast training
    generate_subset = GenerateSubset(
        select_percentage = 0.1
    )
    fe.add_task(
        generate_subset,
        table = (fe, 'data')
    )
    
    basicoperator = BasicOperator(
        operator = '/',
        value = 255.0,
        columns = [
            'data'
        ]
    )
    fe.add_task(
        basicoperator,
        origin_table = (generate_subset, 'selected_table')
    )
    
    select_columns = ColumnSelect(
        columns = [
            'data'
        ]
    )
    fe.add_task(
        select_columns,
        origin_table = (basicoperator, 'out')
    )
    
    select_columns_2 = ColumnSelect(
        columns = [
            'labels'
        ]
    )
    fe.add_task(
        select_columns_2,
        origin_table = (basicoperator, 'out')
    )
    
    fe.add_output('features', (select_columns, 'resulting_table'))
    fe.add_output('truth', (select_columns_2, 'resulting_table'))
    
    return fe

