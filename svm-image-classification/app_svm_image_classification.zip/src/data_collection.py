""" data_collection.py """

from mls_lib.data_collection import PickleLoader
from mls_lib.orchestration import ParamLoader, Stage

def create_data_collection():
    dc =  Stage('Data Collection')

    # data
    pickle_loader = PickleLoader(
        path =  ParamLoader.load('data_collection.dataset_path')
    )
    dc.add_task(
        pickle_loader
    )
    
    # labels
    pickle_loader_2 = PickleLoader(
        path =  ParamLoader.load('data_collection.labels_path')
    )
    dc.add_task(
        pickle_loader_2
    )
    
    dc.add_output('raw_data', (pickle_loader, 'out'))
    dc.add_output('labels', (pickle_loader_2, 'out'))
    
    return dc

