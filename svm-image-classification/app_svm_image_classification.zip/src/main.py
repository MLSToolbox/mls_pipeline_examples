import warnings
warnings.filterwarnings('ignore')

from mls_lib.orchestration import Pipeline
from data_collection import create_data_collection
from feature_engineering import create_feature_engineering
from model_train import create_model_train
from model_evaluation import create_model_evaluation

def main():
    root = Pipeline()
    data_collection = create_data_collection()
    root.add_stage(data_collection, 
    )

    feature_engineering = create_feature_engineering()
    root.add_stage(feature_engineering, 
        data = (data_collection, 'raw_data'),
    )

    model_train = create_model_train()
    root.add_stage(model_train, 
        features = (feature_engineering, 'features'),
        truth = (feature_engineering, 'truth'),
    )

    model_evaluation = create_model_evaluation()
    root.add_stage(model_evaluation, 
        model = (model_train, 'trained_model'),
        features_test = (model_train, 'features_test'),
        labels = (data_collection, 'labels'),
        truth_test = (model_train, 'truth_test'),
    )

    root.execute()

if __name__ == '__main__':
    main()