""" model_train.py """

from mls_lib.model_training import SVMTrainer, TrainTestSplitter
from mls_lib.orchestration import Stage

def create_model_train():
    mt =  Stage('Model Train')

    split_train_test = TrainTestSplitter(
        train_percentage = 0.7
    )
    mt.add_task(
        split_train_test,
        features = (mt, 'features'),
        truth = (mt, 'truth')
    )
    
    svm_train = SVMTrainer(
        kernel = 'linear'
    )
    mt.add_task(
        svm_train,
        features = (split_train_test, 'features_train'),
        truth = (split_train_test, 'truth_train')
    )
    
    mt.add_output('trained_model', (svm_train, 'model'))
    mt.add_output('features_test', (split_train_test, 'features_test'))
    mt.add_output('truth_test', (split_train_test, 'truth_test'))
    
    return mt

