""" split.py """

from mls_lib.model_training import TrainTestSplitter
from mls_lib.orchestration import Stage

def create_split():
    s =  Stage('Split')

    split_train_test = TrainTestSplitter(
        train_percentage = 0
    )
    s.add_task(
        split_train_test,
        features = (s, 'features'),
        truth = (s, 'truth')
    )
    
    s.add_output('truth_test', (split_train_test, 'truth_test'))
    s.add_output('features_test', (split_train_test, 'features_test'))
    s.add_output('truth_train', (split_train_test, 'truth_train'))
    s.add_output('features_train', (split_train_test, 'features_train'))
    
    return s

