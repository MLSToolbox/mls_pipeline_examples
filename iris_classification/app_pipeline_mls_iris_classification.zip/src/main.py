import warnings
warnings.filterwarnings('ignore')

from mls_lib.orchestration import Pipeline
from data_collection import create_data_collection
from model_train_rf import create_model_train_rf
from model_evaluation_rf import create_model_evaluation_rf
from split import create_split
from model_train_svm import create_model_train_svm
from model_evaluation_svm import create_model_evaluation_svm

def main():
    root = Pipeline()
    data_collection = create_data_collection()
    root.add_stage(data_collection, 
    )

    split = create_split()
    root.add_stage(split, 
        features = (data_collection, 'iris_data'),
        truth = (data_collection, 'iris_target'),
    )

    model_train_rf = create_model_train_rf()
    root.add_stage(model_train_rf, 
        truth = (split, 'truth_train'),
        features = (split, 'features_train'),
    )

    model_evaluation_rf = create_model_evaluation_rf()
    root.add_stage(model_evaluation_rf, 
        features = (split, 'features_test'),
        truth = (split, 'truth_test'),
        model = (model_train_rf, 'rf_model'),
    )

    model_train_svm = create_model_train_svm()
    root.add_stage(model_train_svm, 
        truth = (split, 'truth_train'),
        features = (split, 'features_train'),
    )

    model_evaluation_svm = create_model_evaluation_svm()
    root.add_stage(model_evaluation_svm, 
        model = (model_train_svm, 'log_model'),
        truth = (split, 'truth_test'),
        featrures = (split, 'features_test'),
    )

    root.execute()

if __name__ == '__main__':
    main()