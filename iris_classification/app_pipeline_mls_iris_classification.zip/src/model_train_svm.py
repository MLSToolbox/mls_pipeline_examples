""" model_train_svm.py """

from mls_lib.model_training import SVMTrainer
from mls_lib.orchestration import Stage

def create_model_train_svm():
    mts =  Stage('Model Train SVM')

    svm_train = SVMTrainer(
        kernel = 'rbf'
    )
    mts.add_task(
        svm_train,
        features = (mts, 'features'),
        truth = (mts, 'truth')
    )
    
    mts.add_output('log_model', (svm_train, 'model'))
    
    return mts

