""" model_evaluation_svm.py """

from mls_lib.model_evaluation import EvaluateAccuracy
from mls_lib.orchestration import Stage

def create_model_evaluation_svm():
    mes =  Stage('Model evaluation SVM')

    evaluate_accuracy = EvaluateAccuracy()
    mes.add_task(
        evaluate_accuracy,
        model = (mes, 'model'),
        features = (mes, 'featrures'),
        truth = (mes, 'truth')
    )
    
    
    return mes

