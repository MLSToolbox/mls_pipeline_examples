""" model_train_rf.py """

from mls_lib.model_training import RandomForestRegressorTrainer
from mls_lib.orchestration import Stage

def create_model_train_rf():
    mtr =  Stage('Model Train RF')

    random_forest_regressor_train = RandomForestRegressorTrainer(
        n_estimators = 100,
        max_depth = 0,
        min_samples_leaf = 0
    )
    mtr.add_task(
        random_forest_regressor_train,
        features = (mtr, 'features'),
        truth = (mtr, 'truth')
    )
    
    mtr.add_output('rf_model', (random_forest_regressor_train, 'model'))
    
    return mtr

