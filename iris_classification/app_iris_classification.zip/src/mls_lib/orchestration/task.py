""" Task : Represents a task in the pipeline. """

from . step import Step

class Task(Step):
    """ Task : Represents a task in the pipeline. """
