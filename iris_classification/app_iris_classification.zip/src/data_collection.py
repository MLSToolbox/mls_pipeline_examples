""" data_collection.py """

from mls_lib.data_collection import IrisDatasetLoader
from mls_lib.orchestration import Stage

def create_data_collection():
    dc =  Stage('Data Collection')

    irisdatasetloader = IrisDatasetLoader()
    dc.add_task(
        irisdatasetloader
    )
    
    dc.add_output('iris_data', (irisdatasetloader, 'data'))
    dc.add_output('iris_target', (irisdatasetloader, 'target'))
    
    return dc

