""" model_evaluation_rf.py """

from mls_lib.model_evaluation import EvaluateAccuracy
from mls_lib.orchestration import Stage

def create_model_evaluation_rf():
    mer =  Stage('Model evaluation RF')

    evaluate_accuracy = EvaluateAccuracy()
    mer.add_task(
        evaluate_accuracy,
        model = (mer, 'model'),
        features = (mer, 'features'),
        truth = (mer, 'truth')
    )
    
    
    return mer

